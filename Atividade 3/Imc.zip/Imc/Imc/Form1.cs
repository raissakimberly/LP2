﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Imc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        string result;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
  
        }

        private void txtAlt_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAlt.Text, out altura)
              ||
              (altura <= 0))
            {
                MessageBox.Show("Altura Inválida!");
                txtAlt.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtAlt.Clear();
            txtPeso.Clear();
            txtResult.Clear();
        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso)
  ||
  (peso <= 0))
            {
                MessageBox.Show("peso Inválida!");
                txtAlt.Focus();
            }
        }

        private void txtResult_Validated(object sender, EventArgs e)
        {

  } 
        private void btnResult_Click(object sender, EventArgs e)
        {
            imc = peso / (altura*altura);
            imc = Math.Round(imc, 1);

            if (imc < 18.5)
            {
                txtResult.Text = imc+" Magreza";
            }
            else if (imc < 25)
            {
                txtResult.Text = "Normal";
            }
            else if (imc < 30)
            {
                txtResult.Text = "Sobrepeso";
            }
            else if (imc < 40)
            {
                txtResult.Text = "Obeso";
            }
            else
            {
                txtResult.Text = "Obesidade mórbida";
            }
        }
    }
}
