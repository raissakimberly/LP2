﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ProvaLP2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] vetor = new string[12, 4];
            string auxiliar;
            int aux2;
            int produto = 1;
            double totalmes = 0;
            double total = 0;

            for (int i = 0; i < vetor.GetLength(0); i++)
            {
                for (int j = 0; j < vetor.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox("Digite a quantidade do produto", "Entrada de dados");
                    lbEntrada.Items.Add($"Total Entrada do Produto {produto} - Semana {j + 1} - {auxiliar}");
                    if (int.TryParse(auxiliar, out aux2) && aux2 != 0)
                    {
                        totalmes += aux2;
                    }
                    else
                    {
                        MessageBox.Show("Entrada Inválida");
                        break;
                    }
            
                }
                total += totalmes;
                lbEntrada.Items.Add($">> Total Entradas do Produto {totalmes}");
                lbEntrada.Items.Add("-----------------------------------------------------------------");
                produto++;
                totalmes = 0;
            }
            lbEntrada.Items.Add($">> Total geral entrada {total}");
        }
    }
}
