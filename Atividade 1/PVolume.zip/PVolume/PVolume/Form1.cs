﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            double vltRaio;

            if (!double.TryParse(txtRaio.Text, out vltRaio))
            {
                MessageBox.Show("Raio inválido!");
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            double vltAltura;

            if (!double.TryParse(txtRaio.Text, out vltAltura))
            {
                MessageBox.Show("Altura inválido!");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double vlrRaio, vlrAltura;  

            if ((!double.TryParse(txtRaio.Text,out vlrRaio))
                || (!double.TryParse(txtAltura.Text,out vlrAltura)))
            {
                MessageBox.Show("Valores Inválidos!");
                txtRaio.Focus();
            }
            else
            {
                double Volume;
                Volume = Math.PI * Math.Pow(vlrRaio, 2) * vlrAltura;
                txtVolume.Text = Volume.ToString("N2");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
